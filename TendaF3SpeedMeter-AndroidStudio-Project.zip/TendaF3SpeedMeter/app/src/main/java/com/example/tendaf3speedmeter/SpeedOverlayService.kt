package com.example.tendaf3speedmeter

import android.app.Service
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import android.webkit.CookieManager
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class SpeedOverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var panel: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var running = true

    private val poll = object : Runnable {
        override fun run() {
            if (!running) return
            worker.execute { readRouter() }
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, "tenda_speed")
                .setContentTitle("Tenda F3 Speed Meter")
                .setContentText("Router speed popup is running")
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("Tenda F3 Speed Meter")
                .setContentText("Router speed popup is running")
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .build()
        }
        startForeground(7, notification)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        panel = TextView(this).apply {
            text = "Tenda F3\nConnecting…"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(18, 14, 18, 14)
            setBackgroundColor(0xDD202A35.toInt())
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 120 }
        wm.addView(panel, params)
        handler.post(poll)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "tenda_speed", "Tenda speed meter", NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    private fun readRouter() {
        try {
            val base = "http://192.168.0.1/"
            val cookie = CookieManager.getInstance().getCookie(base) ?: ""
            val url = URL("http://192.168.0.1/goform/getStatus?modules=internetStatus,deviceStatistics,systemInfo")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 3500
                readTimeout = 3500
                requestMethod = "GET"
                setRequestProperty("Cookie", cookie)
                setRequestProperty("Referer", base)
            }
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            val root = JSONObject(body)
            val stats = root.optJSONObject("deviceStatistics")
                ?: root.optJSONObject("deviceStastics")
                ?: root.optJSONObject("deviceStatiscs")
            if (stats == null) {
                update("Tenda F3\nData format not found")
                return
            }
            val down = stats.optString("statusDownSpeed", "--")
            val up = stats.optString("statusUpSpeed", "--")
            val devices = stats.optString("statusOnlineNumber", "?")
            update("Tenda F3  •  $devices devices\n↓ $down  |  ↑ $up\nRouter raw units")
        } catch (e: Exception) {
            update("Tenda F3\nConnection/login error")
        }
    }

    private fun update(value: String) {
        handler.post { if (::panel.isInitialized) panel.text = value }
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(poll)
        worker.shutdownNow()
        if (::panel.isInitialized) wm.removeView(panel)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

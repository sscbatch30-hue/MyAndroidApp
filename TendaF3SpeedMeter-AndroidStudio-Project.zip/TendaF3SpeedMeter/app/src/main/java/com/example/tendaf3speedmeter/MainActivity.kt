package com.example.tendaf3speedmeter

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val routerUrl = "http://192.168.0.1/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        val title = TextView(this).apply {
            text = "Tenda F3 Live Speed Meter\n\n১) নিচের পেজে রাউটারে লগইন করো।\n২) লগইন হলে Floating Popup চালু করো।"
            textSize = 18f
        }
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            CookieManager.getInstance().setAcceptCookie(true)
            loadUrl(routerUrl)
        }
        val start = Button(this).apply {
            text = "আমি লগইন করেছি — Floating Popup চালু করো"
            setOnClickListener {
                val cookie = CookieManager.getInstance().getCookie(routerUrl)
                if (cookie.isNullOrBlank()) {
                    Toast.makeText(this@MainActivity, "আগে রাউটারে লগইন করো", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivity(i)
                    Toast.makeText(this@MainActivity, "অনুমতি দিয়ে অ্যাপে ফিরে এসে আবার বাটন চাপো", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                startForegroundService(Intent(this@MainActivity, SpeedOverlayService::class.java))
                Toast.makeText(this@MainActivity, "Speed Popup চালু হয়েছে", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
        val stop = Button(this).apply {
            text = "Popup বন্ধ করো"
            setOnClickListener { stopService(Intent(this@MainActivity, SpeedOverlayService::class.java)) }
        }
        layout.addView(title)
        layout.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        layout.addView(start)
        layout.addView(stop)
        setContentView(layout)
    }
}

Tenda F3 Speed Meter — Android Studio project

এই প্রাথমিক সংস্করণটি তোমার Tenda F3-এর API থেকে:
- statusDownSpeed
- statusUpSpeed
- statusOnlineNumber
পড়ার চেষ্টা করে এবং স্ক্রিনে floating popup দেখায়।

গুরুত্বপূর্ণ:
1. এখনো এটি APK নয়; Android Studio দিয়ে build করতে হবে।
2. তোমার রাউটারের API JSON-এ deviceStatistics / deviceStastics নাম যেটি আছে সেটি কোডে রাখা হয়েছে।
3. Popup-এ আপাতত raw router reading দেখায়; API সংখ্যার সঠিক KB/s/MB/s conversion firmware অনুযায়ী যাচাই করা হয়নি। ভুল unit দেখানো এড়াতে raw units লেখা আছে।
4. MainActivity-র WebView-তে http://192.168.0.1 খুলে নিজে লগইন করবে। Password অ্যাপে আলাদা করে সংরক্ষণ করা হয় না।
5. Overlay permission দিতে হবে।
6. প্রথম পরীক্ষার সময় ফোন Tenda F3-এর Wi-Fi-তে যুক্ত থাকতে হবে।

Build:
- Android Studio-তে এই folder Open করো।
- Gradle sync করো।
- Build > Build APK(s)।
- APK: app/build/outputs/apk/debug/app-debug.apk

নিরাপত্তা:
- এই অ্যাপ শুধু লোকাল নেটওয়ার্কের router page-এ যোগাযোগ করে।
- Router admin password কাউকে পাঠাবে না।
- এটি একটি starter project; তোমার নির্দিষ্ট firmware-এ login cookie/API response ঠিকমতো কাজ করে কি না ফোনে পরীক্ষা করতে হবে।
